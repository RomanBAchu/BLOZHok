from PIL import Image
from collections import namedtuple
from flask import Flask, render_template, redirect, url_for, request
from werkzeug.utils import secure_filename
import os
from datetime import datetime

app = Flask(__name__)

Message = namedtuple('Message', 'text photo user date')
messages = []

@app.route("/", methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        text = request.form['text']
        photo = request.files['photo']
        user = "username"  # имя пользователя
        date = datetime.now()  # текущая дата и время

        if photo.filename != '':
            filename = secure_filename(photo.filename)
            max_width = 1000  # Максимальная ширина фотографии
            image = Image.open(photo)
            image.thumbnail((max_width, max_width))
            image.save(os.path.join(app.static_folder, 'photos', filename))
        else:
            filename = None

        messages.append(Message(text, filename, user, date))
        return redirect(url_for('home'))
    else:
        return render_template('main.html', messages=messages)

@app.route('/add_message', methods=['POST'])
def add_message():
    text = request.form['text']
    photo = request.files['photo']
    user = "username"  # имя пользователя
    date = datetime.now()  # текущая дата и время

    if photo.filename != '':
        filename = secure_filename(photo.filename)
        max_width = 1000  # Максимальная ширина фотографии
        image = Image.open(photo)
        image.thumbnail((max_width, max_width))
        image.save(os.path.join(app.static_folder, 'photos', filename))
    else:
        filename = None

    messages.append(Message(text, filename, user, date))
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)


